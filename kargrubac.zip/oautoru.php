
<?php

include ("header.php");

?>

<div class = "oautoru">

	<div class = "slika">

	<img src = "ja.jpg">;

	</div>

	<div class = "opcenito">

		<p><b>Ime i prezime:</b> <i>Karlo Grubač</i></p>
		<p><b>Broj indexa:</b> <i>125485235 </p>
		<p><b>Mail:</b> <i>kargrubac@foi.hr </p>
		<p><b>Centar:</b> <i>Zabok</i> </p>
		<p><b>Godina:</b> <i>2016/2017</i> </p>

	</div>

</div>

<?php

include("footer.php");

?>




