
<div class="footer">

			<div class= "podaci">

				<p>Kontakt:</p>
				<p>Besplatni telefon: 0800 5588 </p>
				<p>Email: preporuka@igre.hr</p>
				<p>Adresa: Ulica Filipa Latinovića 44a</p> 

			</div>

			<div class="social">
		
				<a href="https://www.facebook.com/"> <img src="facebook.png">

				<a href="https://www.instagram.com/"> <img src="instagram.png">

				<a href="https://twitter.com/"> <img src="twitter.png">

				<a href="https://youtube.com/"> <img src="youtube.png">
		
			</div>						
			
</div>

</div>

</body>

</html>